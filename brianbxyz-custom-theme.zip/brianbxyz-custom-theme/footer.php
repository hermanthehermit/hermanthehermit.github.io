<footer class="container-fluid text-center mt-auto footer">
      <p>Footer Text</p>
    </footer>
    <?php wp_footer(); ?>
  </body>
</html>